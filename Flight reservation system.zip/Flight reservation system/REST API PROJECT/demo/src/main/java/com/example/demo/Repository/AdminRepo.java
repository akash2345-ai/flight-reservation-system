package com.example.demo.Repository;


import com.example.demo.Entity.Admin;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;


@Repository
public interface AdminRepo extends JpaRepository<Admin, Long>{

    List<Admin> findByEmail(String email);

    @Query("SELECT u FROM Admin u WHERE u.passport_number = :num")
    List<Admin> findByPassportnumber(@Param("num") String num);
}