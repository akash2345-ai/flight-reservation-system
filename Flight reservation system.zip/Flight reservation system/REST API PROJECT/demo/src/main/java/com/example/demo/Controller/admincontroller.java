package com.example.demo.Controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Admin;
import com.example.demo.Service.AdminService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/admin")
public class AdminController{
    @Autowired 
    AdminService adminService;
    
   @GetMapping("/view")
   public List<Admin> viewAdmin(){
    return adminService.viewAdmin();
   }

   @PostMapping("/add")
   public Admin addAdmin(@RequestBody Admin Admin){
    return adminService.addAdmin(Admin);
   }

   @DeleteMapping("/delete/{id}")
   public ResponseEntity<String> deleteAdmin(@PathVariable long id){
    adminService.deleteAdmin(id);
    return ResponseEntity.ok("Admin deleted successfully");
   }

   @PutMapping("/update/{id}")
   public ResponseEntity<Admin> updateAdmin(@PathVariable Long id, @RequestBody Admin adminDetails){
    Admin updateAdmin= adminService.updateAdmin(id, adminDetails);
    return ResponseEntity.ok(updateAdmin);
   }

   @GetMapping("/pagination")
   public Page<Admin> getMethod(@RequestParam int page,@RequestParam int size){
    return adminService.getMethod(size, page);
   }

   @GetMapping("/sorted")
   public List<Admin> sortByName(){
    return adminService.sortbyName();
   }

   @GetMapping("/jpql")
   public List<Admin> getbyPassportnumber(@RequestParam("pass") String pass){
    return adminService.getbypassportnumber(pass);
   }

   @GetMapping("/custom-jpa")
   public List<Admin> getbyemail(@RequestParam("email")String email){
    return adminService.getbyEmail(email);
   }
}   