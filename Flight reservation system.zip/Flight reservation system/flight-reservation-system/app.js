const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const flightRoutes = require('./routes/flights');
require('dotenv').config();

const app = express();

// Middleware
app.use(bodyParser.json());
app.use('/flights', flightRoutes);

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
    useFindAndModify: false
}).then(() => {
    console.log('Connected to MongoDB');
}).catch((error) => {
    console.error('Error connecting to MongoDB:', error);
});

module.exports = app;
